Create a new public repository named `submarine-shape-experiment`.
Upload the contents of this project folder.
Suggested commit message: `Create submarine shape fluid dynamics experiment`
Do not upload generated `__pycache__` files.
